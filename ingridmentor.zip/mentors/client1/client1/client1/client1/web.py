import pickle
from flask import Flask, render_template_string, request, redirect, url_for, session
import os

# --- НАСТРОЙКИ ---
ADMIN_LOGIN = "admin"
ADMIN_PASS = "qwerty123"
BASE = os.path.dirname(__file__)
SESSIONS_FILE = os.path.join(BASE, "sessions.pkl")

app = Flask(__name__)
app.secret_key = os.urandom(24)

# --- АВТОРИЗАЦИЯ ---
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        login = request.form.get('login')
        password = request.form.get('password')
        if login == ADMIN_LOGIN and password == ADMIN_PASS:
            session['logged_in'] = True
            return redirect(url_for('index'))
        else:
            return render_template_string(LOGIN_PAGE, error="Неверный логин или пароль!")
    return render_template_string(LOGIN_PAGE)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

def login_required(f):
    def wrapper(*args, **kwargs):
        if not session.get('logged_in'):
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    wrapper.__name__ = f.__name__
    return wrapper

# --- ГЛАВНАЯ СТРАНИЦА ---
@app.route("/")
@login_required
def index():
    if not os.path.exists(SESSIONS_FILE):
        return "Нет данных сессий"
    with open(SESSIONS_FILE, "rb") as f:
        data = pickle.load(f)
    users = []
    for uid, info in data.get("user_data", {}).items():
        hist = info.get("history", [])
        last_time = ""
        if hist and isinstance(hist[-1], dict):
            last_time = hist[-1].get("timestamp", "")
        users.append({
            "user_id": uid,
            "first_name": info.get("first_name", ""),
            "last_name": info.get("last_name", ""),
            "username": info.get("username", ""),
            "history": hist,
            "last_time": last_time
        })
    # Поиск/сортировка
    sort = request.args.get("sort", "last_time")
    order = request.args.get("order", "desc")
    q = request.args.get("q", "").strip().lower()
    if q:
        users = [
            u for u in users
            if q in u["first_name"].lower()
            or q in u["last_name"].lower()
            or q in (u["username"] or "").lower()
        ]
    reverse = (order == "desc")
    if sort == "first_name":
        users.sort(key=lambda x: (x["first_name"] or "").lower(), reverse=reverse)
    elif sort == "last_name":
        users.sort(key=lambda x: (x["last_name"] or "").lower(), reverse=reverse)
    else:
        users.sort(key=lambda x: x["last_time"] or "", reverse=reverse)
    return render_template_string(USER_LIST_PAGE, users=users, sort=sort, order=order, q=q)

# --- СТРАНИЦА ИСТОРИИ ПОЛЬЗОВАТЕЛЯ ---
@app.route("/user/<int:user_id>")
@login_required
def user_history(user_id):
    if not os.path.exists(SESSIONS_FILE):
        return "Нет данных сессий"
    with open(SESSIONS_FILE, "rb") as f:
        data = pickle.load(f)
    info = data["user_data"].get(user_id)
    if not info:
        return "Пользователь не найден"
    return render_template_string(USER_HISTORY_PAGE, info=info, user_id=user_id)

# --- HTML ШАБЛОНЫ (КАК В ТВОЁМ ПРИМЕРЕ) ---
LOGIN_PAGE = """
<!DOCTYPE html>
<html><head><title>Вход</title></head>
<body>
<h2>Вход</h2>
{% if error %}<p style="color:red">{{ error }}</p>{% endif %}
<form method="post">
  <input type="text" name="login" placeholder="Логин"><br>
  <input type="password" name="password" placeholder="Пароль"><br>
  <button type="submit">Войти</button>
</form>
</body></html>
"""

USER_LIST_PAGE = """
<!DOCTYPE html>
<html>
<head>
<title>Пользователи</title>
<style>
body { font-family: Arial, sans-serif; background: #f6f7f8;}
.userlist {max-width:950px;margin:40px auto;background:#fff;padding:30px 20px 50px 20px;border-radius:14px;box-shadow:0 2px 12px #0001;}
table {width:100%;border-collapse:collapse;}
th,td {padding:9px 8px;text-align:left;}
th {background:#f7f7f7;cursor:pointer;user-select:none;}
tr:nth-child(odd) {background: #f5fafd;}
tr:hover {background: #e8f0fb;}
.code { color: #666; background: #f3f3f3; border-radius: 6px; padding: 2px 8px; }
a { text-decoration: none; color: #247ba0;}
a:hover {text-decoration: underline;}
#searchbox {width: 250px; font-size:15px; padding:6px 10px; margin-bottom: 18px;}
.sort-arrow {font-size: 13px; margin-left: 2px;}
</style>
<script>
function doSearch() {
    let val = document.getElementById('searchbox').value.toLowerCase();
    let rows = document.querySelectorAll("tbody tr");
    rows.forEach(tr => {
        let txt = tr.innerText.toLowerCase();
        tr.style.display = txt.includes(val) ? "" : "none";
    });
}
</script>
</head>
<body>
<div class="userlist">
<h2>Пользователи</h2>
<a href="{{ url_for('logout') }}">Выйти</a>
<form method="get" style="margin: 20px 0 12px 0;">
    <input id="searchbox" name="q" placeholder="Поиск по имени, фамилии, username" value="{{ q|default('') }}" oninput="doSearch()" autocomplete="off">
    <button type="submit">Поиск</button>
</form>
<table>
<thead>
<tr>
  <th onclick="window.location.search='?sort=first_name&order={{ 'asc' if sort!='first_name' or order=='desc' else 'desc' }}&q={{ q|default('') }}'">
    Имя
    {% if sort=='first_name' %}
      <span class="sort-arrow">{{ '▲' if order=='asc' else '▼' }}</span>
    {% endif %}
  </th>
  <th onclick="window.location.search='?sort=last_name&order={{ 'asc' if sort!='last_name' or order=='desc' else 'desc' }}&q={{ q|default('') }}'">
    Фамилия
    {% if sort=='last_name' %}
      <span class="sort-arrow">{{ '▲' if order=='asc' else '▼' }}</span>
    {% endif %}
  </th>
  <th>Username</th>
  <th onclick="window.location.search='?sort=last_time&order={{ 'asc' if sort!='last_time' or order=='desc' else 'desc' }}&q={{ q|default('') }}'">
    Последнее сообщение
    {% if sort=='last_time' %}
      <span class="sort-arrow">{{ '▲' if order=='asc' else '▼' }}</span>
    {% endif %}
  </th>
  <th>Смотреть</th>
</tr>
</thead>
<tbody>
{% for u in users %}
  <tr>
    <td>{{ u.first_name }}</td>
    <td>{{ u.last_name }}</td>
    <td><span class="code">@{{ u.username }}</span></td>
    <td>{{ u.last_time }}</td>
    <td><a href="{{ url_for('user_history', user_id=u.user_id) }}">история</a></td>
  </tr>
{% endfor %}
</tbody>
</table>
</div>
<script>
document.getElementById('searchbox').focus();
</script>
</body></html>
"""

USER_HISTORY_PAGE = """
<!DOCTYPE html>
<html>
<head>
  <title>История пользователя</title>
  <style>
    body { font-family: Arial, sans-serif; background: #f6f7f8; }
    .chat-container { max-width: 720px; margin: 32px auto; background: #fff; border-radius: 14px; box-shadow: 0 2px 12px #0001; padding: 30px 30px 60px 30px;}
    .msg { display: flex; margin-bottom: 18px; }
    .msg-user { justify-content: flex-end; }
    .msg-assistant { justify-content: flex-start; }
    .bubble {
      max-width: 75%;
      padding: 13px 16px;
      border-radius: 16px;
      line-height: 1.5;
      font-size: 15px;
      white-space: pre-wrap;
      word-break: break-word;
      position: relative;
    }
    .bubble-user {
      background: #daf6ff;
      color: #222;
      border-bottom-right-radius: 6px;
      border-top-right-radius: 4px;
    }
    .bubble-assistant {
      background: #f1f1f1;
      color: #222;
      border-bottom-left-radius: 6px;
      border-top-left-radius: 4px;
    }
    .meta {
      font-size: 12px;
      color: #777;
      margin: 2px 8px 0 8px;
    }
    .timestamp {
      display: block;
      text-align: right;
      font-size: 11px;
      color: #aaa;
      margin-top: 6px;
      margin-bottom: -10px;
      margin-right: 5px;
    }
    .header { margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; }
    a { text-decoration: none; color: #247ba0; }
    .userinfo { font-size: 17px; margin-bottom: 7px;}
    .scroll-down-btn {
      font-size: 22px;
      background: #34b7f1;
      color: #fff;
      border: none;
      border-radius: 50%;
      width: 44px;
      height: 44px;
      cursor: pointer;
      margin-left: 12px;
      box-shadow: 0 2px 8px #0002;
      transition: background 0.18s;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .scroll-down-btn:hover {
      background: #247ba0;
    }
    @media (max-width: 800px) {
      .chat-container { max-width: 98vw; padding: 8px; }
    }
  </style>
  <script>
    function scrollToBottom() {
      var el = document.getElementById('chat-end');
      if(el) el.scrollIntoView({ behavior: 'smooth' });
    }
    window.onload = function() {
      // scrollToBottom(); // Раскомментируй если хочешь автоскролл при открытии
    }
  </script>
</head>
<body>
<div class="chat-container">
  <div class="header">
    <div>
      <a href="{{ url_for('index') }}">← Назад</a>
      <span class="userinfo">
        <b>{{ info.first_name }} {{ info.last_name }}</b>
        <code>@{{ info.username }}</code>
      </span>
    </div>
    <button class="scroll-down-btn" title="Вниз" onclick="scrollToBottom()">👇</button>
  </div>
  {% for msg in info.history %}
    <div class="msg msg-{{ msg.role }}">
      {% if msg.role == 'user' %}
        <div class="bubble bubble-user">
          {{ msg.content|e }}
          {% if msg.timestamp %}<span class="timestamp">{{ msg.timestamp }}</span>{% endif %}
        </div>
        <span class="meta">Пользователь</span>
      {% else %}
        <span class="meta">Ментор</span>
        <div class="bubble bubble-assistant">
          {{ msg.content|e }}
          {% if msg.timestamp %}<span class="timestamp">{{ msg.timestamp }}</span>{% endif %}
        </div>
      {% endif %}
    </div>
  {% endfor %}
  <div id="chat-end"></div>
</div>
</body>
</html>
"""

if __name__ == "__main__":
    app.run("0.0.0.0", 5041, debug=False)
