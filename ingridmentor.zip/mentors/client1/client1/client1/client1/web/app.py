import os
import pickle
from flask import Flask, render_template_string, request, redirect, url_for, session, flash, send_file, abort
from io import StringIO, BytesIO

SESSIONS_FILE = '/opt/mentorbot/sessions.pkl'
MATERIALS_FOLDER = '/opt/mentorbot/materials'
ACCOUNTS_FILE = '/opt/mentorbot/accounts.pkl'
os.makedirs(MATERIALS_FOLDER, exist_ok=True)
ADMIN_LOGIN = "diman"
ADMIN_PASS = "HuySosiGuboyTryasi"

app = Flask(__name__)
app.secret_key = 'super_secret_key_for_webpanel_2025'

TABS = [
    {'endpoint': 'dashboard', 'label': 'Дашборд'},
    {'endpoint': 'index', 'label': 'Чаты'},
    {'endpoint': 'accounts', 'label': 'Аккаунты'},
    {'endpoint': 'files', 'label': 'Файлы'},
    {'endpoint': 'stats', 'label': 'Статистика'},
    {'endpoint': 'logout', 'label': 'Выход'}
]

def active_tab(endpoint):
    def mark(tab):
        t = tab.copy()
        t['active'] = (t['endpoint'] == endpoint)
        return t
    return [mark(tab) for tab in TABS]

def load_accounts():
    if os.path.exists(ACCOUNTS_FILE):
        with open(ACCOUNTS_FILE, "rb") as f:
            return pickle.load(f)
    else:
        return {"allow_all": False, "groups": {}, "accounts": []}

def save_accounts(data):
    with open(ACCOUNTS_FILE, "wb") as f:
        pickle.dump(data, f)

def sync_names(data):
    # Синхронизируем имя/фамилию по username из sessions.pkl
    if os.path.exists(SESSIONS_FILE):
        with open(SESSIONS_FILE, "rb") as f:
            session_data = pickle.load(f)
        name_by_username = {v.get('username'): (v.get('first_name', ''), v.get('last_name', ''))
                            for v in session_data.get("user_data", {}).values() if v.get("username")}
        for gname, users in data["groups"].items():
            for u in users:
                fn, ln = name_by_username.get(u['username'], (u.get("first_name",""), u.get("last_name","")))
                u['first_name'] = fn
                u['last_name'] = ln
        for u in data["accounts"]:
            fn, ln = name_by_username.get(u['username'], (u.get("first_name",""), u.get("last_name","")))
            u['first_name'] = fn
            u['last_name'] = ln
        save_accounts(data)

def find_account(data, username):
    for u in data['accounts']:
        if u['username'] == username:
            return u
    for group in data['groups'].values():
        for u in group:
            if u['username'] == username:
                return u
    return None

# ==== LOGIN ====
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        login = request.form.get('login')
        password = request.form.get('password')
        if login == ADMIN_LOGIN and password == ADMIN_PASS:
            session['logged_in'] = True
            return redirect(url_for('dashboard'))
        else:
            flash('Неверный логин или пароль!')
    return render_template_string(LOGIN_PAGE)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

def login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('logged_in'):
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

# ==== ROOT REDIRECT ====
@app.route("/")
@login_required
def root():
    return redirect(url_for('dashboard'))

# ==== ДАШБОРД ====
@app.route("/dashboard")
@login_required
def dashboard():
    users, total_msgs, last_user = [], 0, None
    if os.path.exists(SESSIONS_FILE):
        with open(SESSIONS_FILE, "rb") as f:
            data = pickle.load(f)
        for uid, info in data.get("user_data", {}).items():
            hist = info.get("history", [])
            total_msgs += len(hist)
            users.append(info)
        if users:
            last_user = sorted(users, key=lambda x: (x["history"][-1]["timestamp"] if x["history"] else ""), reverse=True)[0]
    stats = {
        "users": len(users),
        "total_msgs": total_msgs,
        "last_user": last_user["first_name"] + " " + last_user["last_name"] if last_user else "",
    }
    return render_template_string(DASHBOARD_PAGE, tabs=active_tab("dashboard"), stats=stats)

# ==== ЧАТЫ ====
@app.route("/chats")
@login_required
def index():
    if not os.path.exists(SESSIONS_FILE):
        users = []
    else:
        with open(SESSIONS_FILE, "rb") as f:
            data = pickle.load(f)
        users = []
        for uid, info in data.get("user_data", {}).items():
            hist = info.get("history", [])
            last_time = ""
            if hist and isinstance(hist[-1], dict):
                last_time = hist[-1].get("timestamp", "")
            users.append({
                "user_id": uid,
                "first_name": info.get("first_name", ""),
                "last_name": info.get("last_name", ""),
                "username": info.get("username", ""),
                "history": hist,
                "last_time": last_time
            })
        sort = request.args.get("sort", "last_time")
        order = request.args.get("order", "desc")
        q = request.args.get("q", "").strip().lower()
        if q:
            users = [
                u for u in users
                if q in u["first_name"].lower()
                or q in u["last_name"].lower()
                or q in (u["username"] or "").lower()
            ]
        reverse = (order == "desc")
        if sort == "first_name":
            users.sort(key=lambda x: (x["first_name"] or "").lower(), reverse=reverse)
        elif sort == "last_name":
            users.sort(key=lambda x: (x["last_name"] or "").lower(), reverse=reverse)
        else:
            users.sort(key=lambda x: x["last_time"] or "", reverse=reverse)

    return render_template_string(USER_LIST_PAGE, users=users, sort=sort, order=order, q=q, tabs=active_tab("index"))

@app.route("/user/<int:user_id>")
@login_required
def user_history(user_id):
    with open(SESSIONS_FILE, "rb") as f:
        data = pickle.load(f)
    info = data.get("user_data", {}).get(user_id)
    if not info:
        return "Пользователь не найден"
    return render_template_string(USER_HISTORY_PAGE, info=info, user_id=user_id, tabs=active_tab("index"))

# ==== АККАУНТЫ ====
@app.route('/accounts', methods=['GET', 'POST'])
@login_required
def accounts():
    data = load_accounts()
    msg = ""
    # POST actions
    if request.method == "POST":
        # Toggle allow_all
        if "toggle_allow_all" in request.form:
            data["allow_all"] = not data.get("allow_all", False)
            save_accounts(data)
            msg = "Параметр доступа обновлён"
        # Импорт данных
        elif "import_data" in request.form:
            file = request.files.get("import_file")
            if file and file.filename:
                groups = {}
                accounts = []
                group_name = None
                for line in file.stream:
                    s = line.decode("utf-8").strip()
                    if not s:
                        continue
                    if s.startswith("@"):
                        items = s.split()
                        username = items[0][1:]
                        first_name = items[1] if len(items) > 1 else ""
                        last_name = items[2] if len(items) > 2 else ""
                        user = {"username": username, "first_name": first_name, "last_name": last_name, "status": "active"}
                        if group_name:
                            groups.setdefault(group_name, []).append(user)
                        else:
                            accounts.append(user)
                    else:
                        group_name = s
                        groups.setdefault(group_name, [])
                data["groups"] = groups
                data["accounts"] = accounts
                save_accounts(data)
                msg = "Данные импортированы"
        # Экспорт данных
        elif "export_data" in request.form:
            output = StringIO()
            for gname, users in data["groups"].items():
                output.write(f"{gname}\n")
                for u in users:
                    fio = f"{u.get('first_name','')} {u.get('last_name','')}".strip()
                    output.write(f"@{u['username']}" + (f" {fio}" if fio else "") + "\n")
            if data["accounts"]:
                output.write("Отдельные\n")
                for u in data["accounts"]:
                    fio = f"{u.get('first_name','')} {u.get('last_name','')}".strip()
                    output.write(f"@{u['username']}" + (f" {fio}" if fio else "") + "\n")
            return send_file(BytesIO(output.getvalue().encode("utf-8")), as_attachment=True, download_name="accounts_export.txt", mimetype="text/plain")
        # Создать группу
        elif "create_group" in request.form:
            group_name = request.form.get("group_name", "").strip()
            if group_name and group_name not in data["groups"]:
                data["groups"][group_name] = []
                save_accounts(data)
                msg = f"Группа {group_name} создана"
        # Удалить группу
        elif "delete_group" in request.form:
            group_name = request.form.get("delete_group")
            if group_name in data["groups"]:
                del data["groups"][group_name]
                save_accounts(data)
                msg = f"Группа {group_name} удалена"
        # Переименовать группу
        elif "rename_group" in request.form:
            old_name = request.form.get("old_group_name")
            new_name = request.form.get("new_group_name", "").strip()
            if old_name in data["groups"] and new_name:
                data["groups"][new_name] = data["groups"].pop(old_name)
                save_accounts(data)
                msg = f"Группа {old_name} переименована в {new_name}"
        # Заблокировать группу
        elif "block_group" in request.form:
            group_name = request.form.get("block_group")
            if group_name in data["groups"]:
                for u in data["groups"][group_name]:
                    u["status"] = "blocked"
                save_accounts(data)
                msg = f"Группа {group_name} заблокирована"
        # Добавить аккаунты в группу
        elif "add_to_group" in request.form:
            group_name = request.form.get("add_to_group")
            new_usernames = request.form.get("new_usernames", "").split()
            for username in new_usernames:
                username = username.strip().lstrip("@")
                if username and not find_account(data, username):
                    data["groups"][group_name].append({"username": username, "first_name": "", "last_name": "", "status": "active"})
            save_accounts(data)
            msg = f"Добавлены пользователи в {group_name}"
        # Удалить пользователя
        elif "delete_user" in request.form:
            username = request.form.get("delete_user")
            for acc in data["accounts"]:
                if acc["username"] == username:
                    data["accounts"].remove(acc)
                    msg = f"Пользователь @{username} удалён"
                    break
            for users in data["groups"].values():
                for acc in users:
                    if acc["username"] == username:
                        users.remove(acc)
                        msg = f"Пользователь @{username} удалён"
                        break
            save_accounts(data)
        # Заблокировать пользователя
        elif "block_user" in request.form:
            username = request.form.get("block_user")
            u = find_account(data, username)
            if u:
                u["status"] = "blocked"
                save_accounts(data)
                msg = f"Пользователь @{username} заблокирован"
        # Добавить в группу
        elif "move_user_to_group" in request.form:
            username = request.form.get("move_user_to_group")
            target_group = request.form.get("target_group")
            u = find_account(data, username)
            if u and target_group in data["groups"]:
                # Удалить из всех мест
                for acc in data["accounts"]:
                    if acc["username"] == username:
                        data["accounts"].remove(acc)
                        break
                for group, users in data["groups"].items():
                    for acc in users:
                        if acc["username"] == username:
                            users.remove(acc)
                            break
                # Добавить в новую группу
                data["groups"][target_group].append(u)
                save_accounts(data)
                msg = f"@{username} добавлен в {target_group}"
        # Создать пользователя
        elif "create_user" in request.form:
            username = request.form.get("new_username", "").strip().lstrip("@")
            if username and not find_account(data, username):
                data["accounts"].append({"username": username, "first_name": "", "last_name": "", "status": "active"})
                save_accounts(data)
                msg = f"Пользователь @{username} создан"
    sync_names(data)
    return render_template_string(ACCOUNTS_PAGE, data=data, msg=msg, tabs=active_tab("accounts"))

# ==== ФАЙЛЫ ====
@app.route("/files", methods=["GET", "POST"])
@login_required
def files():
    msg = ""
    if request.method == 'POST':
        if "file" in request.files:
            file = request.files['file']
            if file and file.filename.endswith('.txt'):
                fname = file.filename
                file.save(os.path.join(MATERIALS_FOLDER, fname))
                msg = "Файл успешно загружен."
        elif "delete" in request.form:
            fname = request.form.get("filename")
            fpath = os.path.join(MATERIALS_FOLDER, fname)
            if os.path.exists(fpath):
                os.remove(fpath)
                msg = "Файл удалён."
        elif "edit" in request.form:
            fname = request.form.get("filename")
            content = request.form.get("filecontent", "")
            fpath = os.path.join(MATERIALS_FOLDER, fname)
            with open(fpath, "w", encoding="utf-8") as f:
                f.write(content)
            msg = "Файл изменён."
    files_list = os.listdir(MATERIALS_FOLDER)
    edit_content = ""
    edit_file = request.args.get("edit")
    if edit_file and edit_file in files_list:
        with open(os.path.join(MATERIALS_FOLDER, edit_file), encoding="utf-8") as f:
            edit_content = f.read()
    return render_template_string(FILES_PAGE, files=files_list, msg=msg, edit_file=edit_file, edit_content=edit_content, tabs=active_tab("files"))

# ==== СТАТИСТИКА ====
@app.route("/stats")
@login_required
def stats():
    users, total_msgs = 0, 0
    if os.path.exists(SESSIONS_FILE):
        with open(SESSIONS_FILE, "rb") as f:
            data = pickle.load(f)
        users = len(data.get("user_data", {}))
        for info in data.get("user_data", {}).values():
            total_msgs += len(info.get("history", []))
    return render_template_string(STATS_PAGE, users=users, total_msgs=total_msgs, tabs=active_tab("stats"))

# ==== ШАБЛОНЫ HTML ====
BASE_HEAD = """
<head>
<meta charset="utf-8">
<title>MentorBot Web Panel</title>
<style>
body { font-family: Arial,sans-serif; background:#f7fafd;}
.tabs { background:#217dbb; color:#fff; display:flex; border-radius:16px; overflow:hidden; max-width:1000px; margin:0 auto 20px auto; }
.tabs a { flex:1; text-align:center; text-decoration:none; color:#d4ebff; padding:16px 0; font-weight:500; transition:0.2s;}
.tabs a.active { background:#fff; color:#217dbb; font-weight:700; }
.container { max-width:1000px; margin:36px auto 0 auto; background:#fff; border-radius:20px; box-shadow:0 2px 16px #0001; padding:36px 36px 66px 36px;}
h2 { color:#217dbb; }
input, button, textarea { font-size:15px; border-radius:7px;}
footer {text-align:center;margin-top:60px;color:#8aa; font-size:13px;}
summary {cursor:pointer;}
details ul {margin:10px 0 10px 24px;}
button.action {background:#217dbb;color:#fff;border:none;padding:2px 9px; margin-left:8px;}
button.cascade {font-size:13px;padding:0 4px; margin-left:5px;}
</style>
<script>
function showRenameGroup(old_name) {
  var new_name = prompt("Новое имя для группы:", old_name);
  if (new_name && new_name !== old_name) {
    var f = document.getElementById("rename_group_form_"+old_name);
    f.elements["new_group_name"].value = new_name;
    f.submit();
  }
}
function showAddToGroup(group_name) {
  var usernames = prompt("Введите username через пробел:");
  if (usernames) {
    var f = document.getElementById("add_to_group_form_"+group_name);
    f.elements["new_usernames"].value = usernames;
    f.submit();
  }
}
function showCreateUser() {
  var username = prompt("Введите username:");
  if (username) {
    var f = document.getElementById("create_user_form");
    f.elements["new_username"].value = username;
    f.submit();
  }
}
function moveUserToGroup(username) {
  var group = prompt("Введите имя группы для добавления:");
  if (group) {
    var f = document.getElementById("move_user_form_"+username);
    f.elements["target_group"].value = group;
    f.submit();
  }
}
</script>
</head>
"""

def render_tabs(tabs):
    return '<div class="tabs">' + ''.join([
        f'<a href="{url_for(tab["endpoint"])}" class="{"active" if tab["active"] else ""}">{tab["label"]}</a>' for tab in tabs
    ]) + '</div>'

LOGIN_PAGE = f"""<!DOCTYPE html>
<html>
{BASE_HEAD}
<body>
<div style="max-width:380px;margin:100px auto 0 auto;background:#fff;border-radius:16px;box-shadow:0 4px 22px #001a2b16;padding:40px 34px 34px 34px;">
    <div style="text-align:center;font-size:23px;font-weight:700;margin-bottom:30px;color:#1561a6;">Личный кабинет для отладки</div>
    {{% with messages = get_flashed_messages() %}}
      {{% if messages %}}
        <div style="color:#d33;text-align:center;margin-bottom:8px;">{{{{ messages[0] }}}}</div>
      {{% endif %}}
    {{% endwith %}}
    <form method="post">
      <input type="text" name="login" placeholder="Логин" style="width:100%;padding:12px;margin-bottom:18px;" autofocus autocomplete="username">
      <input type="password" name="password" placeholder="Пароль" style="width:100%;padding:12px;margin-bottom:18px;" autocomplete="current-password">
      <button type="submit" style="width:100%;padding:12px;background:#217dbb;color:#fff;border:none;">Войти</button>
    </form>
</div>
<footer>Разработано и поддерживается Ингрид &copy; 2025</footer>
</body>
</html>
"""

DASHBOARD_PAGE = """<!DOCTYPE html>
<html>
""" + BASE_HEAD + """
<body>
{{ render_tabs(tabs)|safe }}
<div class="container">
<h2>Дашборд</h2>
<p>Пользователей: <b>{{ stats.users }}</b></p>
<p>Всего сообщений: <b>{{ stats.total_msgs }}</b></p>
<p>Последний пользователь: <b>{{ stats.last_user }}</b></p>
<p style="color:#888">Тут могут быть красивые графики, активность по дням и т.д.</p>
</div>
<footer>Разработано и поддерживается Ингрид &copy; 2025</footer>
</body>
</html>
"""

USER_LIST_PAGE = """<!DOCTYPE html>
<html>
""" + BASE_HEAD + """
<body>
{{ render_tabs(tabs)|safe }}
<div class="container">
<h2>Пользователи</h2>
<form method="get" style="margin: 10px 0 18px 0;">
    <input id="searchbox" name="q" placeholder="Поиск по имени, фамилии, username" value="{{ q|default('') }}" style="width:250px; padding:6px 10px;">
    <button type="submit">Поиск</button>
</form>
<table style="width:100%;border-collapse:collapse;">
<thead>
<tr>
  <th onclick="window.location.search='?sort=first_name&order={{ 'asc' if sort!='first_name' or order=='desc' else 'desc' }}&q={{ q|default('') }}'">Имя</th>
  <th onclick="window.location.search='?sort=last_name&order={{ 'asc' if sort!='last_name' or order=='desc' else 'desc' }}&q={{ q|default('') }}'">Фамилия</th>
  <th>Username</th>
  <th onclick="window.location.search='?sort=last_time&order={{ 'asc' if sort!='last_time' or order=='desc' else 'desc' }}&q={{ q|default('') }}'">Последнее сообщение</th>
  <th>Смотреть</th>
</tr>
</thead>
<tbody>
{% for u in users %}
  <tr>
    <td>{{ u.first_name }}</td>
    <td>{{ u.last_name }}</td>
    <td>@{{ u.username }}</td>
    <td>{{ u.last_time }}</td>
    <td><a href="{{ url_for('user_history', user_id=u.user_id) }}">история</a></td>
  </tr>
{% endfor %}
</tbody>
</table>
</div>
<footer>Разработано и поддерживается Ингрид &copy; 2025</footer>
</body>
</html>
"""

USER_HISTORY_PAGE = """<!DOCTYPE html>
<html>
""" + BASE_HEAD + """
<body>
{{ render_tabs(tabs)|safe }}
<div class="container" style="max-width: 800px;">
  <a href="{{ url_for('index') }}">&larr; Назад к списку чатов</a>
  <div style="font-size:17px; margin-bottom:12px; margin-top:16px;">
      <b>{{ info.first_name }} {{ info.last_name }}</b>
      <code>@{{ info.username }}</code>
  </div>
  <div style="margin:20px 0;">
    {% for msg in info.history %}
      <div style="margin-bottom:20px;">
        {% if msg.role == 'user' %}
          <div style="background:#daf6ff; padding:13px 16px; border-radius:16px; margin-left:40px; text-align:right;">{{ msg.content|e }}<br>
            <span style="font-size:11px;color:#888;">{{ msg.timestamp }}</span>
          </div>
          <span style="font-size:12px;color:#888;float:right;">Пользователь</span>
        {% else %}
          <span style="font-size:12px;color:#888;">AURA</span>
          <div style="background:#f1f1f1; padding:13px 16px; border-radius:16px; margin-right:40px; text-align:left;">{{ msg.content|e }}
            <br><span style="font-size:11px;color:#888;">{{ msg.timestamp }}</span>
          </div>
        {% endif %}
      </div>
    {% endfor %}
  </div>
</div>
<footer>Разработано и поддерживается Ингрид &copy; 2025</footer>
</body>
</html>
"""

FILES_PAGE = """<!DOCTYPE html>
<html>
""" + BASE_HEAD + """
<body>
{{ render_tabs(tabs)|safe }}
<div class="container">
<h2>Файлы (материалы)</h2>
{% if msg %}<div style="color:#11841c;margin-bottom:12px;">{{ msg }}</div>{% endif %}
<form method="post" enctype="multipart/form-data">
    <input type="file" name="file" accept=".txt">
    <button type="submit">Загрузить</button>
</form>
<table style="margin-top:15px;width:100%;border-collapse:collapse;">
<thead><tr><th>Файл</th><th>Действия</th></tr></thead>
<tbody>
{% for f in files %}
  <tr>
    <td>{{ f }}</td>
    <td>
      <form method="post" style="display:inline">
        <input type="hidden" name="filename" value="{{ f }}">
        <button type="submit" name="delete" onclick="return confirm('Удалить файл?')">Удалить</button>
      </form>
      <a href="?edit={{ f }}">Редактировать</a>
    </td>
  </tr>
{% endfor %}
</tbody>
</table>
{% if edit_file %}
<hr>
<h4>Редактирование файла: {{ edit_file }}</h4>
<form method="post">
  <input type="hidden" name="filename" value="{{ edit_file }}">
  <textarea name="filecontent" rows="18" style="width:100%">{{ edit_content }}</textarea>
  <button type="submit" name="edit">Сохранить</button>
</form>
{% endif %}
</div>
<footer>Разработано и поддерживается Ингрид &copy; 2025</footer>
</body>
</html>
"""

STATS_PAGE = """<!DOCTYPE html>
<html>
""" + BASE_HEAD + """
<body>
{{ render_tabs(tabs)|safe }}
<div class="container">
<h2>Статистика</h2>
<p>Пользователей: <b>{{ users }}</b></p>
<p>Всего сообщений: <b>{{ total_msgs }}</b></p>
<p style="color:#888;">Здесь может быть развёрнутая статистика по выбранному периоду, графики активности, медиана диалога и др.</p>
</div>
<footer>Разработано и поддерживается Ингрид &copy; 2025</footer>
</body>
</html>
"""

# ==== Вкладка АККАУНТЫ ====
ACCOUNTS_PAGE = """<!DOCTYPE html>
<html>
""" + BASE_HEAD + """
<body>
{{ render_tabs(tabs)|safe }}
<div class="container">
<h2>Аккаунты</h2>
{% if msg %}<div style="color:#11841c;margin-bottom:12px;">{{ msg }}</div>{% endif %}

<form method="post" style="margin-bottom:18px;">
  <input type="hidden" name="toggle_allow_all" value="1">
  <label><input type="checkbox" name="allow_all" onclick="this.form.submit()" {% if data.allow_all %}checked{% endif %}> Разрешить доступ к боту без ограничений</label>
</form>
<div style="margin-bottom:20px;">
  <form method="post" enctype="multipart/form-data" style="display:inline">
    <input type="file" name="import_file" accept=".txt" required>
    <button type="submit" name="import_data">Импорт данных</button>
  </form>
  <form method="post" style="display:inline">
    <button type="submit" name="export_data">Экспорт данных</button>
  </form>
  <form method="post" style="display:inline;margin-left:14px;">
    <input type="hidden" name="create_group" value="1">
    <input type="text" name="group_name" placeholder="Создать группу" style="padding:4px 9px;">
    <button type="submit">Создать</button>
  </form>
  <button type="button" onclick="showCreateUser()" style="margin-left:12px;">Создать пользователя</button>
  <form id="create_user_form" method="post" style="display:none;">
    <input type="hidden" name="create_user" value="1">
    <input type="hidden" name="new_username">
  </form>
</div>

{% if data.groups %}
<h4 style="margin:20px 0 5px 0;">Группы:</h4>
{% for gname, users in data.groups.items() %}
<details style="margin-bottom:7px;">
  <summary>
    <b>{{ gname }}</b> <span style="color:#888;">({{ users|length }})</span>
    <button class="cascade" onclick="event.preventDefault(); document.getElementById('block_group_form_{{gname}}').submit();">Заблокировать</button>
    <button class="cascade" onclick="event.preventDefault(); showRenameGroup('{{gname}}');">Переименовать</button>
    <form method="post" style="display:inline" id="block_group_form_{{gname}}">
      <input type="hidden" name="block_group" value="{{gname}}">
    </form>
    <form method="post" style="display:inline" id="rename_group_form_{{gname}}">
      <input type="hidden" name="rename_group" value="1">
      <input type="hidden" name="old_group_name" value="{{gname}}">
      <input type="hidden" name="new_group_name" value="">
    </form>
    <button class="cascade" onclick="event.preventDefault(); document.getElementById('delete_group_form_{{gname}}').submit();">Удалить</button>
    <form method="post" style="display:inline" id="delete_group_form_{{gname}}">
      <input type="hidden" name="delete_group" value="{{gname}}">
    </form>
    <button class="cascade" onclick="event.preventDefault(); showAddToGroup('{{gname}}');">Добавить</button>
    <form method="post" style="display:inline" id="add_to_group_form_{{gname}}">
      <input type="hidden" name="add_to_group" value="{{gname}}">
      <input type="hidden" name="new_usernames" value="">
    </form>
  </summary>
  <ul>
    {% for u in users %}
      <li>
        {{ u.first_name }} {{ u.last_name }} <b>@{{ u.username }}</b>
        [{{ u.status }}]
        <button class="action" onclick="event.preventDefault(); document.getElementById('block_user_form_{{u.username}}').submit();">Заблокировать</button>
        <form method="post" style="display:inline" id="block_user_form_{{u.username}}">
          <input type="hidden" name="block_user" value="{{u.username}}">
        </form>
        <button class="action" onclick="event.preventDefault(); document.getElementById('delete_user_form_{{u.username}}').submit();">Удалить</button>
        <form method="post" style="display:inline" id="delete_user_form_{{u.username}}">
          <input type="hidden" name="delete_user" value="{{u.username}}">
        </form>
        <button class="action" onclick="event.preventDefault(); moveUserToGroup('{{u.username}}');">Добавить в группу</button>
        <form method="post" style="display:inline" id="move_user_form_{{u.username}}">
          <input type="hidden" name="move_user_to_group" value="{{u.username}}">
          <input type="hidden" name="target_group" value="">
        </form>
      </li>
    {% endfor %}
  </ul>
</details>
{% endfor %}
{% endif %}

{% if data.accounts %}
<h4 style="margin:20px 0 5px 0;">Аккаунты вне групп:</h4>
<ul>
{% for u in data.accounts %}
  <li>
    {{ u.first_name }} {{ u.last_name }} <b>@{{ u.username }}</b>
    [{{ u.status }}]
    <button class="action" onclick="event.preventDefault(); document.getElementById('block_user_form_{{u.username}}').submit();">Заблокировать</button>
    <form method="post" style="display:inline" id="block_user_form_{{u.username}}">
      <input type="hidden" name="block_user" value="{{u.username}}">
    </form>
    <button class="action" onclick="event.preventDefault(); document.getElementById('delete_user_form_{{u.username}}').submit();">Удалить</button>
    <form method="post" style="display:inline" id="delete_user_form_{{u.username}}">
      <input type="hidden" name="delete_user" value="{{u.username}}">
    </form>
    <button class="action" onclick="event.preventDefault(); moveUserToGroup('{{u.username}}');">Добавить в группу</button>
    <form method="post" style="display:inline" id="move_user_form_{{u.username}}">
      <input type="hidden" name="move_user_to_group" value="{{u.username}}">
      <input type="hidden" name="target_group" value="">
    </form>
  </li>
{% endfor %}
</ul>
{% endif %}

{% if not data.groups and not data.accounts %}
<div style="color:#aaa;">Нет аккаунтов или групп.</div>
{% endif %}

</div>
<footer>Разработано и поддерживается Ингрид &copy; 2025</footer>
</body>
</html>
"""

@app.context_processor
def inject_render_tabs():
    return dict(render_tabs=render_tabs)

# ==== Фильтр доступа для бота (пример функции) ====
def is_allowed(username):
    data = load_accounts()
    if data.get("allow_all"):
        return True
    username = username.lstrip("@")
    for u in data['accounts']:
        if u['username'] == username and u.get('status', 'active') == 'active':
            return True
    for group in data['groups'].values():
        for u in group:
            if u['username'] == username and u.get('status', 'active') == 'active':
                return True
    return False

if __name__ == "__main__":
    app.run("0.0.0.0", 5041, debug=False)
